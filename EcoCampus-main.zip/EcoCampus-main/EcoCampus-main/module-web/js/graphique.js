// =====================================================================
// graphique.js — F7 : graphique de consommation par mois (Chart.js)
// =====================================================================

const COULEURS = { electricite: "#D99A0B", eau: "#2F7FC1", gaz: "#4E9A6E" };
let graphique = null;

// "2026-03" -> "mars 2026"
function nomMois(anneeMois) {
  return new Date(anneeMois + "-01T00:00:00")
    .toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
}

function dessinerGraphique(mesures) {
  // Chart.js n'a pas pu être chargé (pas d'internet)
  if (typeof Chart === "undefined") {
    document.querySelector(".zone-graphique").innerHTML =
      '<p class="aide">Graphique indisponible : connectez-vous à internet pour charger Chart.js.</p>';
    return;
  }

  // Regroupement par jour (AAAA-MM-JJ) ou par mois (AAAA-MM)
  const nbMois = new Set(mesures.map((m) => m.date.slice(0, 7))).size;
  const parJour = nbMois <= 1;
  const periode = (m) => (parJour ? m.date : m.date.slice(0, 7));

  // Les périodes présentes, de la plus ancienne à la plus récente
  const periodes = [...new Set(mesures.map(periode))].sort();
  // Ressources présentes, dans l'ordre électricité, eau, gaz
  const ressources = listeRessources().filter((code) => mesures.some((m) => m.ressource === code));

  // Une série de barres par ressource : total de chaque période
  const series = ressources.map((code) => ({
    label: `${libelleRessource(code)} (${formaterUnite(UNITES[code])})`,
    backgroundColor: COULEURS[code] || "#8A97A0",
    borderRadius: 4,
    data: periodes.map((p) =>
      mesures
        .filter((m) => m.ressource === code && periode(m) === p)
        .reduce((somme, m) => somme + m.valeur, 0)
    ),
  }));

  document.getElementById("titre-graphique").textContent =
    parJour ? "Consommation par jour" : "Consommation par mois";

  // On recrée le graphique à chaque changement de filtre
  if (graphique) graphique.destroy();

  graphique = new Chart(document.getElementById("graphique"), {
    type: "bar",
    data: { labels: periodes.map((p) => (parJour ? formaterDate(p) : nomMois(p))), datasets: series },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: "bottom" } },
      scales: { y: { beginAtZero: true } },
    },
  });
}
